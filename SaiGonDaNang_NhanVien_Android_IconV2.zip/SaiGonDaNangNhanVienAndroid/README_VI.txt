SÀI GÒN ĐA NĂNG - ỨNG DỤNG NHÂN VIÊN (DỰ ÁN ANDROID)

Ứng dụng mở đúng trang hiện tại:
http://103.90.224.157:3000/nhan-vien

APK chưa được build trong môi trường tạo file hiện tại vì máy không có Android SDK/Gradle và không truy cập Internet để tải các công cụ build. Không đổi URL hoặc API; ứng dụng dùng WebView để hiển thị chính trang web, vì vậy dữ liệu tiếp tục đi qua VPS.

Cách tạo APK:
1. Cài Android Studio trên máy tính Windows.
2. Giải nén thư mục SaiGonDaNangNhanVienAndroid.
3. Android Studio > Open > chọn thư mục này.
4. Chờ Gradle Sync hoàn tất (cần Internet để tải Android Gradle Plugin/SDK nếu máy chưa có).
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug thường ở app/build/outputs/apk/debug/app-debug.apk.

Lưu ý: đây là dự án nguồn Android, không phải file APK đã build. Cần build và cài thử trên điện thoại Android trước khi phát hành.
